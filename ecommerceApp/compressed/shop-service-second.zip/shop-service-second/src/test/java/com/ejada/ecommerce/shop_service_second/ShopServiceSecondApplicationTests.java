package com.ejada.ecommerce.shop_service_second;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ShopServiceSecondApplicationTests {

	@Test
	void contextLoads() {
	}

}
