package com.ejada.ecommerce.shop_service_second;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ShopServiceSecondApplication {

	public static void main(String[] args) {
		SpringApplication.run(ShopServiceSecondApplication.class, args);
	}

}
