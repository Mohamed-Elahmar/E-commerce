package com.ejada.ecommerce.wallet_service_first;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class WalletServiceFirstApplicationTests {

	@Test
	void contextLoads() {
	}

}
