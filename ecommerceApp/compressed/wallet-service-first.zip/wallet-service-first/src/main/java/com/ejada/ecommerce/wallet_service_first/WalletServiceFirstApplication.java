package com.ejada.ecommerce.wallet_service_first;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class WalletServiceFirstApplication {

	public static void main(String[] args) {
		SpringApplication.run(WalletServiceFirstApplication.class, args);
	}

}
