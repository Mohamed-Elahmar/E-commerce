package com.ejada.ecommerce.inventory_service_first;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class InventoryServiceFirstApplication {

	public static void main(String[] args) {
		SpringApplication.run(InventoryServiceFirstApplication.class, args);
	}

}
