package com.ejada.ecommerce.inventory_service_first;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class InventoryServiceFirstApplicationTests {

	@Test
	void contextLoads() {
	}

}
