package com.ejada.ecommerce.wallet_service_second;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class WalletServiceSecondApplication {

	public static void main(String[] args) {
		SpringApplication.run(WalletServiceSecondApplication.class, args);
	}

}
