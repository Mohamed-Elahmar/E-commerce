package com.ejada.ecommerce.wallet_service_second;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class WalletServiceSecondApplicationTests {

	@Test
	void contextLoads() {
	}

}
