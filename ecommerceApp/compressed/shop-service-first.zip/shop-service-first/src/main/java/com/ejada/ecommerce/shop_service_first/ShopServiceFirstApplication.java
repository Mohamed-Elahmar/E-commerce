package com.ejada.ecommerce.shop_service_first;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ShopServiceFirstApplication {

	public static void main(String[] args) {
		SpringApplication.run(ShopServiceFirstApplication.class, args);
	}

}
