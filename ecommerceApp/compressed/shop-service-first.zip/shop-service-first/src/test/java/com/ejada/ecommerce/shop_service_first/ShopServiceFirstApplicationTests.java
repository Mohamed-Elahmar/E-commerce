package com.ejada.ecommerce.shop_service_first;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ShopServiceFirstApplicationTests {

	@Test
	void contextLoads() {
	}

}
